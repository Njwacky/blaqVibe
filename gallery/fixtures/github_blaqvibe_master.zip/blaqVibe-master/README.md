# BlaqVibes

**GitHub stores the code. BlaqVibes tells the story of what you're building.**

BlaqVibes is a creator network for builders and their projects: **BUILD → SHOW → REMIX → COMPETE → REPEAT**.

Publish what you made, get feedback, discover creators, remix ideas, take on challenges, and build a reputation around your work. You can build by hand, use AI as a tool, or remix another project — the platform does not treat any one creation method as the identity of the project.

## The core loop

1. **Build** something.
2. **Show** the working project, README, progress and trust status.
3. **Remix** another creator's idea or let someone remix yours.
4. **Compete** through challenges, battles, stars and reputation.
5. **Repeat** with BlaqVibes Today showing what happened and what to do next.

## Five places, on purpose

The primary navigation is **Projects · Discover · Skills · Challenges · Build**, and nothing else. Everything that is a utility — Saved, Inbox, Battle, Launch guides, Nolo, Trades, Sales, Settings, Admin — lives in the account menu, because the first thing anyone should see is what people are building.

- **Projects** (`/`) — the feed of what bu